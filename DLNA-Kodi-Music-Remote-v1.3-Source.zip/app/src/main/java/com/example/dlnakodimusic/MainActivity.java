package com.example.dlnakodimusic;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** One-phone-app controller. Kodi plays DLNA URLs directly from the media server. */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 15, 24);
    private static final int PANEL = Color.rgb(22, 32, 45);
    private static final int LINE = Color.rgb(35, 48, 62);
    private static final int ACCENT = Color.rgb(80, 197, 223);
    private static final int WHITE = Color.rgb(242, 247, 250);
    private static final int MUTED = Color.rgb(157, 174, 189);

    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final ExecutorService covers = Executors.newFixedThreadPool(2);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final KodiClient kodi = new KodiClient();
    private final List<DlnaClient.Server> servers = new ArrayList<>();
    private final List<DlnaClient.Entry> items = new ArrayList<>();
    private final List<DlnaClient.Entry> lastPlaylist = new ArrayList<>();
    private final LinkedHashSet<String> selected = new LinkedHashSet<>();
    private final Deque<Folder> history = new ArrayDeque<>();
    private final AtomicBoolean isPolling = new AtomicBoolean(false);
    private final LruCache<String, Bitmap> coverCache = new LruCache<>(40);
    private final ListAdapter adapter = new ListAdapter();
    private DlnaClient.Server server;
    private String folderId = "0", folderName = "根目录";
    private boolean disposed = false, seekDragging = false, volumeDragging = false;
    private boolean settingsShown;

    private LinearLayout settingsPanel;
    private EditText ipEdit, portEdit, userEdit, passwordEdit;
    private TextView status, serverName, location, currentTitle, currentArtist, playbackTime, volumeValue;
    private ImageView currentCover;
    private SeekBar seek, volume;
    private Button setupToggle, playSelected, playerToggle;

    private static final class Folder {
        final String id, name;
        Folder(String id, String name) { this.id = id; this.name = name; }
    }
    private interface Callback<T> { void accept(T value); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        String ip = prefs.getString("kodiIp", "");
        int port = prefs.getInt("kodiPort", 8080);
        String user = prefs.getString("kodiUser", "");
        String password = prefs.getString("kodiPassword", "");
        kodi.configure(ip, port, user, password);
        settingsShown = ip.isEmpty();
        buildUi(ip, port, user, password);
        if (!ip.isEmpty()) testKodi(false);
        scan();
    }

    private void buildUi(String ip, int port, String user, String pass) {
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(8), dp(12), dp(10));
        setContentView(root);

        LinearLayout bar = row();
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = label("DLNA ♪ Kodi", 22, WHITE, true);
        bar.addView(heading, new LinearLayout.LayoutParams(0, dp(48), 1));
        heading.setGravity(Gravity.CENTER_VERTICAL);
        setupToggle = button(settingsShown ? "收起设置" : "连接设置", false);
        setupToggle.setOnClickListener(v -> {
            settingsShown = !settingsShown;
            settingsPanel.setVisibility(settingsShown ? View.VISIBLE : View.GONE);
            setupToggle.setText(settingsShown ? "收起设置" : "连接设置");
        });
        bar.addView(setupToggle);
        root.addView(bar);

        settingsPanel = column();
        settingsPanel.setPadding(dp(10), dp(8), dp(10), dp(10));
        settingsPanel.setBackground(round(PANEL, 14));
        settingsPanel.setVisibility(settingsShown ? View.VISIBLE : View.GONE);
        root.addView(settingsPanel, new LinearLayout.LayoutParams(-1, -2));
        TextView explain = label("电视 Kodi → 设置 → 服务 → 控制 → 允许通过 HTTP 远程控制", 12, MUTED, false);
        settingsPanel.addView(explain);
        LinearLayout line1 = row();
        ipEdit = edit("Kodi IP，如 192.168.1.20", ip, 1);
        ipEdit.setSingleLine(true);
        line1.addView(ipEdit, new LinearLayout.LayoutParams(0, dp(46), 3));
        portEdit = edit("端口", String.valueOf(port), 2);
        portEdit.setInputType(InputType.TYPE_CLASS_NUMBER);
        line1.addView(portEdit, new LinearLayout.LayoutParams(0, dp(46), 1));
        settingsPanel.addView(line1);
        LinearLayout line2 = row();
        userEdit = edit("Kodi 用户名", user, 1);
        line2.addView(userEdit, new LinearLayout.LayoutParams(0, dp(44), 1));
        passwordEdit = edit("Kodi 密码", pass, 1);
        passwordEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        line2.addView(passwordEdit, new LinearLayout.LayoutParams(0, dp(44), 1));
        settingsPanel.addView(line2);
        Button connect = button("保存并测试 Kodi 连接", true);
        connect.setOnClickListener(v -> testKodi(true));
        settingsPanel.addView(connect, new LinearLayout.LayoutParams(-1, dp(43)));

        status = label("准备连接…", 12, MUTED, false);
        status.setPadding(dp(3), dp(7), 0, dp(7));
        root.addView(status);

        LinearLayout serverBar = row();
        serverBar.setGravity(Gravity.CENTER_VERTICAL);
        serverName = label("DLNA：尚未发现服务器", 14, WHITE, true);
        serverName.setSingleLine(true);
        serverName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        serverName.setOnClickListener(v -> chooseServer());
        serverBar.addView(serverName, new LinearLayout.LayoutParams(0, dp(42), 1));
        Button scan = button("扫描", false);
        scan.setOnClickListener(v -> scan());
        serverBar.addView(scan);
        Button manual = button("手动", false);
        manual.setOnClickListener(v -> manualServer());
        serverBar.addView(manual);
        root.addView(serverBar);

        LinearLayout folderBar = row();
        folderBar.setGravity(Gravity.CENTER_VERTICAL);
        location = label("目录：未选择 DLNA 服务器", 13, MUTED, false);
        location.setSingleLine(true);
        location.setEllipsize(android.text.TextUtils.TruncateAt.START);
        folderBar.addView(location, new LinearLayout.LayoutParams(0, dp(35), 1));
        Button up = button("上一级", false);
        up.setOnClickListener(v -> upFolder());
        folderBar.addView(up);
        Button reload = button("刷新", false);
        reload.setOnClickListener(v -> loadFolder(folderId, folderName, null));
        folderBar.addView(reload);
        root.addView(folderBar);

        LinearLayout actions = row();
        actions.setGravity(Gravity.CENTER_VERTICAL);
        Button playFolder = button("▶ 整个文件夹", true);
        playFolder.setOnClickListener(v -> playFolder(folderId));
        actions.addView(playFolder, new LinearLayout.LayoutParams(0, dp(46), 1.3f));
        Button selectAll = button("全选 / 取消", false);
        selectAll.setOnClickListener(v -> selectAll());
        actions.addView(selectAll, new LinearLayout.LayoutParams(0, dp(46), 1f));
        playSelected = button("▶ 已选(0)", false);
        playSelected.setOnClickListener(v -> playSelected());
        actions.addView(playSelected, new LinearLayout.LayoutParams(0, dp(46), 1f));
        root.addView(actions);

        ListView list = new ListView(this);
        list.setDivider(new android.graphics.drawable.ColorDrawable(LINE));
        list.setDividerHeight(dp(1));
        list.setSelector(new android.graphics.drawable.ColorDrawable(PANEL));
        list.setCacheColorHint(BG);
        list.setBackgroundColor(BG);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= items.size()) return;
            DlnaClient.Entry entry = items.get(position);
            if (entry.folder) openFolder(entry);
            else if (entry.playable()) playTracks(java.util.Collections.singletonList(entry));
            else toast("这首歌曲没有可用的 HTTP 播放地址");
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position >= items.size()) return false;
            DlnaClient.Entry entry = items.get(position);
            if (entry.folder) playFolder(entry.id);
            else toggleSelect(entry);
            return true;
        });
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout player = column();
        player.setPadding(dp(10), dp(10), dp(10), dp(7));
        player.setBackground(round(PANEL, 16));
        LinearLayout nowPlaying = row();
        nowPlaying.setGravity(Gravity.CENTER_VERTICAL);
        currentCover = new ImageView(this);
        currentCover.setBackground(round(LINE, 8));
        currentCover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        currentCover.setContentDescription("专辑封面");
        nowPlaying.addView(currentCover, new LinearLayout.LayoutParams(dp(49), dp(49)));
        LinearLayout titles = column();
        titles.setPadding(dp(10), 0, dp(4), 0);
        currentTitle = label("电视暂无音乐播放", 16, WHITE, true);
        currentTitle.setSingleLine(true);
        currentTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titles.addView(currentTitle);
        currentArtist = label("手机负责控制，电视 Kodi 直接播放", 12, MUTED, false);
        currentArtist.setSingleLine(true);
        currentArtist.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titles.addView(currentArtist);
        nowPlaying.addView(titles, new LinearLayout.LayoutParams(0, dp(50), 1));
        Button update = button("↻", false);
        update.setOnClickListener(v -> refreshPlayer());
        nowPlaying.addView(update);
        player.addView(nowPlaying);

        LinearLayout seekRow = row();
        seekRow.setGravity(Gravity.CENTER_VERTICAL);
        seek = new SeekBar(this);
        seek.setMax(100);
        seek.setEnabled(false);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seekRow.addView(seek, new LinearLayout.LayoutParams(0, dp(34), 1));
        playbackTime = label("00:00 / 00:00", 11, MUTED, false);
        seekRow.addView(playbackTime);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar bar) { seekDragging = true; }
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean user) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {
                seekDragging = false;
                command(() -> kodi.seek(bar.getProgress()));
            }
        });
        player.addView(seekRow);

        LinearLayout buttons = row();
        buttons.setGravity(Gravity.CENTER);
        Button prev = button("⏮ 上一首", false);
        prev.setOnClickListener(v -> command(() -> kodi.previous()));
        buttons.addView(prev, new LinearLayout.LayoutParams(0, dp(43), 1));
        playerToggle = button("⏯ 播放/暂停", true);
        playerToggle.setOnClickListener(v -> command(() -> kodi.toggle()));
        buttons.addView(playerToggle, new LinearLayout.LayoutParams(0, dp(43), 1.3f));
        Button next = button("下一首 ⏭", false);
        next.setOnClickListener(v -> command(() -> kodi.next()));
        buttons.addView(next, new LinearLayout.LayoutParams(0, dp(43), 1));
        Button stop = button("■", false);
        stop.setOnClickListener(v -> command(() -> kodi.stop()));
        buttons.addView(stop, new LinearLayout.LayoutParams(0, dp(43), .55f));
        player.addView(buttons);

        LinearLayout volumeRow = row();
        volumeRow.setGravity(Gravity.CENTER_VERTICAL);
        volumeRow.addView(label("音量", 12, MUTED, false));
        volume = new SeekBar(this);
        volume.setMax(100); volume.setProgress(50);
        volume.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        volumeRow.addView(volume, new LinearLayout.LayoutParams(0, dp(32), 1));
        volumeValue = label("50%", 11, MUTED, false);
        volumeRow.addView(volumeValue);
        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar bar) { volumeDragging = true; }
            @Override public void onProgressChanged(SeekBar bar, int value, boolean user) {
                if (user) volumeValue.setText(value + "%");
            }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                volumeDragging = false;
                int desired = bar.getProgress();
                command(() -> kodi.volume(desired));
            }
        });
        player.addView(volumeRow);
        root.addView(player);
    }

    private void testKodi(boolean save) {
        if (save) {
            String host = ipEdit.getText().toString().trim();
            String portText = portEdit.getText().toString().trim();
            int p;
            try { p = Integer.parseInt(portText); }
            catch (NumberFormatException ex) { toast("请填写正确的 Kodi 端口号"); return; }
            if (host.isEmpty() || host.contains("/") || p < 1 || p > 65535) {
                toast("Kodi IP 或端口不正确，不要填写 http://"); return;
            }
            String username = userEdit.getText().toString();
            String password = passwordEdit.getText().toString();
            kodi.configure(host, p, username, password);
            getPreferences(MODE_PRIVATE).edit().putString("kodiIp", host)
                    .putInt("kodiPort", p).putString("kodiUser", username)
                    .putString("kodiPassword", password).apply();
        }
        setStatus("正在测试 Kodi HTTP 控制…");
        task(() -> { kodi.ping(); return true; }, ok -> {
            setStatus("✓ Kodi 已连接，可以从 DLNA 选择歌曲播放");
            settingsPanel.setVisibility(View.GONE);
            settingsShown = false;
            setupToggle.setText("连接设置");
            refreshPlayer();
        });
    }

    private void scan() {
        setStatus("正在搜索 DLNA/UPnP 音乐服务器…");
        task(() -> {
            WifiManager.MulticastLock lock = null;
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            try {
                if (wifi != null) {
                    lock = wifi.createMulticastLock("DLNAKodiMusicScan");
                    lock.setReferenceCounted(false);
                    lock.acquire();
                }
                return DlnaClient.discover();
            } finally { if (lock != null && lock.isHeld()) lock.release(); }
        }, found -> {
            servers.clear(); servers.addAll(found);
            if (found.isEmpty()) setStatus("未发现 DLNA 服务器，请检查同一 Wi-Fi 或使用「手动」");
            else {
                setStatus("发现 " + found.size() + " 台 DLNA 服务器");
                if (server == null && found.size() == 1) selectServer(found.get(0));
                else chooseServer();
            }
        });
    }

    private void manualServer() {
        EditText field = edit("例如 http://192.168.1.30:8200/rootDesc.xml", "", 1);
        field.setLayoutParams(new ViewGroup.LayoutParams(-1, dp(50)));
        new AlertDialog.Builder(this)
                .setTitle("手动添加 DLNA 设备")
                .setMessage("请输入 UPnP 设备描述 XML 的完整地址（不是音乐文件夹路径）。")
                .setView(field)
                .setNegativeButton("取消", null)
                .setPositiveButton("连接", (dialog, which) -> {
                    String url = field.getText().toString().trim();
                    task(() -> {
                        DlnaClient.Server remote = DlnaClient.fromDescription(url);
                        if (remote == null) throw new IllegalStateException("此设备不提供 DLNA ContentDirectory 服务");
                        return remote;
                    }, discovered -> {
                        servers.add(discovered);
                        selectServer(discovered);
                    });
                }).show();
    }
    private void chooseServer() {
        if (servers.isEmpty()) { toast("尚未发现 DLNA 设备，请点击扫描"); return; }
        String[] names = new String[servers.size()];
        for (int i = 0; i < names.length; i++) names[i] = servers.get(i).name;
        new AlertDialog.Builder(this).setTitle("选择 DLNA 音乐服务器")
                .setItems(names, (dialog, index) -> selectServer(servers.get(index)))
                .setNegativeButton("取消", null).show();
    }
    private void selectServer(DlnaClient.Server chosen) {
        server = chosen;
        serverName.setText("DLNA：" + chosen.name + " ▾");
        history.clear();
        loadFolder("0", "根目录", null);
    }
    private void openFolder(DlnaClient.Entry entry) {
        String oldId = folderId, oldName = folderName;
        loadFolder(entry.id, entry.title, () -> history.push(new Folder(oldId, oldName)));
    }
    private void upFolder() {
        if (history.isEmpty()) { toast("已经是根目录"); return; }
        Folder up = history.peek();
        loadFolder(up.id, up.name, () -> history.pop());
    }
    private void loadFolder(String id, String name, Runnable onSuccess) {
        if (server == null) { toast("先选择 DLNA 音乐服务器"); return; }
        DlnaClient.Server chosen = server;
        setStatus("读取音乐目录：" + name + "…");
        task(() -> DlnaClient.browse(chosen, id), entries -> {
            if (server != chosen) return;
            if (onSuccess != null) onSuccess.run();
            folderId = id; folderName = name;
            items.clear(); items.addAll(entries);
            selected.clear();
            adapter.notifyDataSetChanged();
            setSelectionCount();
            location.setText("目录：" + chosen.name + " / " + name);
            int songs = 0, folders = 0;
            for (DlnaClient.Entry entry : entries) {
                if (entry.folder) folders++;
                else songs++;
            }
            setStatus("当前目录：" + folders + " 个文件夹、" + songs + " 首音乐；点歌曲播放，长按文件夹播放全部");
        });
    }

    private void toggleSelect(DlnaClient.Entry entry) {
        if (!entry.playable()) { toast("歌曲缺少可播放地址"); return; }
        if (selected.contains(entry.id)) selected.remove(entry.id);
        else selected.add(entry.id);
        adapter.notifyDataSetChanged();
        setSelectionCount();
    }
    private void selectAll() {
        int playable = 0;
        for (DlnaClient.Entry entry : items) if (entry.playable()) playable++;
        boolean allSelected = playable > 0 && selected.size() == playable;
        selected.clear();
        if (!allSelected) for (DlnaClient.Entry entry : items)
            if (entry.playable()) selected.add(entry.id);
        adapter.notifyDataSetChanged();
        setSelectionCount();
    }
    private void setSelectionCount() {
        playSelected.setText("▶ 已选(" + selected.size() + ")");
    }
    private void playSelected() {
        List<DlnaClient.Entry> wanted = new ArrayList<>();
        for (DlnaClient.Entry entry : items)
            if (entry.playable() && selected.contains(entry.id)) wanted.add(entry);
        if (wanted.isEmpty()) { toast("请先勾选音乐文件"); return; }
        playTracks(wanted);
    }
    private void playFolder(String id) {
        if (server == null) { toast("请先选择 DLNA 服务器"); return; }
        DlnaClient.Server chosen = server;
        setStatus("正在收集文件夹内的音乐（包含子文件夹）…");
        task(() -> DlnaClient.collectFolder(chosen, id), tracks -> {
            if (tracks.isEmpty()) { toast("文件夹里没有可通过 HTTP 播放的音乐"); return; }
            playTracks(tracks);
        });
    }
    private void playTracks(List<DlnaClient.Entry> tracks) {
        List<DlnaClient.Entry> playlist = new ArrayList<>(tracks);
        setStatus("正在将 " + playlist.size() + " 首音乐发送到电视 Kodi…");
        task(() -> { kodi.play(playlist); return playlist.size(); }, count -> {
            lastPlaylist.clear(); lastPlaylist.addAll(playlist);
            setStatus("✓ 已发送 " + count + " 首，电视 Kodi 直接从 DLNA 硬盘读取");
            if (!playlist.isEmpty()) showCurrentTrack(playlist.get(0));
            refreshPlayer();
        });
    }

    private interface KodiAction { void run() throws Exception; }
    private void command(KodiAction action) {
        task(() -> { action.run(); return true; }, ok -> refreshPlayer());
    }
    private void refreshPlayer() {
        if (!isPolling.compareAndSet(false, true)) return;
        network.execute(() -> {
            try {
                KodiClient.State state = kodi.state();
                runOnUiThread(() -> { if (!disposed) renderPlayer(state); });
            } catch (Exception ex) {
                // Poll failures should not flood the UI with transient toast messages.
            } finally { isPolling.set(false); }
        });
    }
    private void renderPlayer(KodiClient.State state) {
        volumeValue.setText(state.volume + "%");
        if (!volumeDragging) volume.setProgress(state.volume);
        playbackTime.setText(state.time);
        seek.setEnabled(state.playing && state.canSeek);
        if (!seekDragging) seek.setProgress((int) Math.round(Math.max(0, Math.min(100, state.percentage))));
        playerToggle.setText(state.paused ? "▶ 继续播放" : "⏯ 播放/暂停");
        if (!state.playing) {
            currentTitle.setText("电视暂无音乐播放");
            currentArtist.setText("选择 DLNA 歌曲即可让 Kodi 播放");
            currentCover.setImageDrawable(null);
            return;
        }
        if (state.playlistPosition >= 0 && state.playlistPosition < lastPlaylist.size()
                && (state.file.isEmpty() || state.file.equals(lastPlaylist.get(state.playlistPosition).mediaUrl))) {
            showCurrentTrack(lastPlaylist.get(state.playlistPosition));
        } else {
            currentTitle.setText(state.title.isEmpty() ? "播放中" : state.title);
            currentArtist.setText((state.artist + "  " + state.album).trim());
            currentCover.setImageDrawable(null);
        }
    }
    private void showCurrentTrack(DlnaClient.Entry entry) {
        currentTitle.setText(entry.title);
        String subtitle = (entry.artist + (entry.album.isEmpty() ? "" : " · " + entry.album)).trim();
        currentArtist.setText(subtitle.isEmpty() ? "来自 DLNA 音乐服务器" : subtitle);
        loadCover(currentCover, entry.coverUrl);
    }

    private final Runnable pollLoop = new Runnable() {
        @Override public void run() {
            if (disposed) return;
            refreshPlayer();
            handler.postDelayed(this, 3500);
        }
    };
    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(pollLoop);
        handler.postDelayed(pollLoop, 1800);
    }
    @Override protected void onPause() {
        handler.removeCallbacks(pollLoop);
        super.onPause();
    }
    @Override protected void onDestroy() {
        disposed = true;
        handler.removeCallbacks(pollLoop);
        network.shutdownNow(); covers.shutdownNow();
        super.onDestroy();
    }

    private <T> void task(Callable<T> request, Callback<T> success) {
        network.execute(() -> {
            try {
                T result = request.call();
                runOnUiThread(() -> { if (!disposed) success.accept(result); });
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    if (!disposed) {
                        String error = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                        setStatus("失败：" + error);
                        toast(error);
                    }
                });
            }
        });
    }

    private final class ListAdapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int position) { return items.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public View getView(int position, View convertView, ViewGroup parent) {
            DlnaClient.Entry entry = items.get(position);
            LinearLayout outer = row();
            outer.setGravity(Gravity.CENTER_VERTICAL);
            outer.setPadding(dp(4), dp(6), dp(2), dp(6));
            if (entry.folder) {
                TextView icon = label("▣", 24, ACCENT, true);
                icon.setGravity(Gravity.CENTER);
                outer.addView(icon, new LinearLayout.LayoutParams(dp(49), dp(52)));
            } else {
                ImageView cover = new ImageView(MainActivity.this);
                cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
                cover.setBackground(round(PANEL, 7));
                outer.addView(cover, new LinearLayout.LayoutParams(dp(49), dp(49)));
                loadCover(cover, entry.coverUrl);
            }
            LinearLayout details = column();
            details.setPadding(dp(10), 0, dp(4), 0);
            TextView title = label(entry.title, 14, WHITE, true);
            title.setSingleLine(true);
            title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            details.addView(title);
            String subtext = entry.folder ? "点击名称进入 · 右侧 ▶ 播放全部" :
                    (entry.artist.isEmpty() ? "音乐文件" : entry.artist) +
                    (entry.album.isEmpty() ? "" : " · " + entry.album);
            TextView subtitle = label(subtext, 11, MUTED, false);
            subtitle.setSingleLine(true);
            subtitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
            details.addView(subtitle);
            outer.addView(details, new LinearLayout.LayoutParams(0, dp(58), 1));
            // ListView rows include a real Button / CheckBox. Their default focusability
            // can prevent ListView.OnItemClickListener from ever firing. Handle taps
            // explicitly on the row, and keep the right-hand action independent.
            outer.setFocusable(false);
            outer.setOnClickListener(v -> {
                if (entry.folder) openFolder(entry);
                else if (entry.playable()) playTracks(java.util.Collections.singletonList(entry));
                else toast("这首歌曲没有可用的 HTTP 播放地址");
            });
            if (entry.folder) {
                // Both icon and text must open the folder, not play it.
                // Taps on the right-hand button alone play the entire folder.
                View iconView = outer.getChildAt(0);
                iconView.setOnClickListener(v -> openFolder(entry));
                details.setOnClickListener(v -> openFolder(entry));
                Button all = button("▶", false);
                all.setFocusable(false);
                all.setContentDescription("播放整个文件夹：" + entry.title);
                all.setOnClickListener(v -> playFolder(entry.id));
                outer.addView(all, new LinearLayout.LayoutParams(dp(45), dp(40)));
            } else {
                CheckBox check = new CheckBox(MainActivity.this);
                check.setFocusable(false);
                check.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
                check.setContentDescription("选择歌曲 " + entry.title);
                check.setChecked(selected.contains(entry.id));
                check.setOnCheckedChangeListener((buttonView, value) -> {
                    if (value) selected.add(entry.id); else selected.remove(entry.id);
                    setSelectionCount();
                });
                outer.addView(check, new LinearLayout.LayoutParams(dp(47), dp(48)));
            }
            return outer;
        }
    }

    private void loadCover(ImageView view, String rawUrl) {
        String url = rawUrl == null ? "" : rawUrl;
        view.setTag(url);
        if (url.isEmpty() || (!url.startsWith("http://") && !url.startsWith("https://"))) {
            view.setImageDrawable(null); return;
        }
        Bitmap cached = coverCache.get(url);
        if (cached != null) { view.setImageBitmap(cached); return; }
        view.setImageDrawable(null);
        covers.execute(() -> {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(4000); conn.setReadTimeout(5000);
                if (conn.getResponseCode() / 100 != 2) return;
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (InputStream stream = conn.getInputStream()) {
                    byte[] buffer = new byte[4096]; int n;
                    while ((n = stream.read(buffer)) > 0) {
                        if (bytes.size() + n > 2 * 1024 * 1024) return;
                        bytes.write(buffer, 0, n);
                    }
                }
                BitmapFactory.Options opt = new BitmapFactory.Options();
                opt.inSampleSize = 2;
                Bitmap img = BitmapFactory.decodeByteArray(bytes.toByteArray(), 0, bytes.size(), opt);
                if (img == null) return;
                runOnUiThread(() -> {
                    if (disposed) return;
                    coverCache.put(url, img);
                    if (url.equals(view.getTag())) view.setImageBitmap(img);
                });
            } catch (Exception ignored) { }
            finally { if (conn != null) conn.disconnect(); }
        });
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
    private void setStatus(String message) { status.setText(message); }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color); drawable.setCornerRadius(dp(radius));
        return drawable;
    }
    private TextView label(String text, int size, int color, boolean strong) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(color);
        if (strong) v.setTypeface(null, android.graphics.Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }
    private Button button(String text, boolean emphasized) {
        Button button = new Button(this);
        button.setText(text); button.setAllCaps(false); button.setTextSize(12);
        button.setTextColor(emphasized ? BG : WHITE);
        button.setBackground(round(emphasized ? ACCENT : LINE, 9));
        button.setMinWidth(0); button.setMinimumWidth(0);
        button.setMinHeight(0); button.setMinimumHeight(0);
        LinearLayout.LayoutParams padding = new LinearLayout.LayoutParams(-2, dp(39));
        padding.setMargins(dp(2), dp(2), dp(2), dp(2));
        button.setPadding(dp(9), 0, dp(9), 0);
        button.setLayoutParams(padding);
        return button;
    }
    private EditText edit(String hint, String value, int weight) {
        EditText e = new EditText(this);
        e.setText(value); e.setHint(hint); e.setTextColor(WHITE); e.setHintTextColor(MUTED);
        e.setTextSize(13); e.setSingleLine(true);
        e.setBackground(round(LINE, 8));
        e.setPadding(dp(9), dp(5), dp(9), dp(5));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), weight);
        p.setMargins(dp(2), dp(4), dp(2), dp(4));
        e.setLayoutParams(p);
        return e;
    }
}
