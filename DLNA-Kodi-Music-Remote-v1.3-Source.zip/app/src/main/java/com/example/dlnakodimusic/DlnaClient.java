package com.example.dlnakodimusic;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.xml.parsers.DocumentBuilderFactory;

/** Browse UPnP ContentDirectory directly; never transfers music through the phone. */
public final class DlnaClient {
    private DlnaClient() {}
    private static final int MAX_FOLDER_ITEMS = 3000;
    private static final int MAX_PLAYLIST_TRACKS = 1000;

    public static final class Server {
        public final String name, location, controlUrl, serviceType;
        public Server(String name, String location, String controlUrl, String serviceType) {
            this.name = name; this.location = location;
            this.controlUrl = controlUrl; this.serviceType = serviceType;
        }
        @Override public String toString() { return name; }
    }

    public static final class Entry {
        public final String id, title, artist, album, mediaUrl, coverUrl;
        public final boolean folder;
        public Entry(String id, String title, String artist, String album,
                     String mediaUrl, String coverUrl, boolean folder) {
            this.id = id; this.title = title; this.artist = artist; this.album = album;
            this.mediaUrl = mediaUrl; this.coverUrl = coverUrl; this.folder = folder;
        }
        public boolean playable() { return !folder && mediaUrl != null && !mediaUrl.isEmpty(); }
    }

    /** SSDP M-SEARCH. Distinct server description URLs only. */
    public static List<Server> discover() throws Exception {
        Map<String, String> descriptions = new LinkedHashMap<>();
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setSoTimeout(600);
            socket.setBroadcast(true);
            InetAddress multicast = InetAddress.getByName("239.255.255.250");
            for (String searchTarget : new String[]{"urn:schemas-upnp-org:device:MediaServer:1", "ssdp:all"}) {
                String message = "M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\n" +
                        "MX: 2\r\n" +
                        "ST: " + searchTarget + "\r\n\r\n";
                byte[] bytes = message.getBytes(StandardCharsets.UTF_8);
                socket.send(new DatagramPacket(bytes, bytes.length, multicast, 1900));
            }
            long end = System.currentTimeMillis() + 3800;
            while (System.currentTimeMillis() < end) {
                byte[] buffer = new byte[8192];
                DatagramPacket response = new DatagramPacket(buffer, buffer.length);
                try { socket.receive(response); }
                catch (java.net.SocketTimeoutException ignored) { continue; }
                String text = new String(response.getData(), response.getOffset(),
                        response.getLength(), StandardCharsets.UTF_8);
                for (String line : text.split("\\r?\\n")) {
                    int colon = line.indexOf(':');
                    if (colon > 0 && line.substring(0, colon).trim().equalsIgnoreCase("location")) {
                        String url = line.substring(colon + 1).trim();
                        if (url.startsWith("http://") || url.startsWith("https://"))
                            descriptions.put(url, url);
                    }
                }
            }
        }
        List<Server> servers = new ArrayList<>();
        for (String location : descriptions.keySet()) {
            try {
                Server server = fromDescription(location);
                if (server != null) servers.add(server);
            } catch (Exception ignored) { /* Other UPnP devices are not media servers. */ }
        }
        return servers;
    }

    /** Can be used when SSDP multicast is blocked by the router. */
    public static Server fromDescription(String location) throws Exception {
        if (!location.startsWith("http://") && !location.startsWith("https://"))
            throw new IOException("请填写 http:// 开头的 DLNA 设备描述地址");
        Document doc = parse(fetch(location));
        Element root = doc.getDocumentElement();
        String name = firstText(root, "friendlyName");
        String base = firstText(root, "URLBase");
        if (base.isEmpty()) base = location;
        NodeList services = root.getElementsByTagName("service");
        // getElementsByTagNameNS used for servers that prefix service elements.
        if (services.getLength() == 0) services = root.getElementsByTagNameNS("*", "service");
        for (int i = 0; i < services.getLength(); i++) {
            Element el = (Element) services.item(i);
            String type = firstText(el, "serviceType");
            if (!type.contains("ContentDirectory")) continue;
            String path = firstText(el, "controlURL");
            if (!path.isEmpty()) {
                URL control = new URL(new URL(base), path);
                return new Server(name.isEmpty() ? "DLNA MediaServer" : name,
                        location, control.toString(), type);
            }
        }
        return null;
    }

    public static List<Entry> browse(Server server, String objectId) throws Exception {
        List<Entry> all = new ArrayList<>();
        int offset = 0;
        String previousFirstId = null;
        while (offset < MAX_FOLDER_ITEMS) {
            Document doc = parse(postBrowse(server, objectId, offset, 100));
            Element result = firstElement(doc.getDocumentElement(), "Result");
            if (result == null) throw new IOException("DLNA 服务器没有返回 Result，无法浏览目录");
            String didl = result.getTextContent();
            if (didl == null || didl.trim().isEmpty()) break;
            Document listing = parse(didl.getBytes(StandardCharsets.UTF_8));
            List<Entry> page = parseEntries(listing, server.controlUrl);
            // Pagination must count ALL server entries, including non-audio files
            // filtered from this music UI (e.g. folder.jpg or videos).
            int received = intOr(firstText(doc.getDocumentElement(), "NumberReturned"), -1);
            if (received < 0) received = countChildren(listing.getDocumentElement());
            if (received == 0) break;
            if (!page.isEmpty()) {
                String firstId = page.get(0).id;
                if (offset > 0 && firstId.equals(previousFirstId)) break;
                previousFirstId = firstId;
                all.addAll(page);
            }
            offset += received;
            String totalText = firstText(doc.getDocumentElement(), "TotalMatches");
            int total = intOr(totalText, -1);
            if (total > 0 && offset >= total) break;
            if (received < 100) break;
            if (offset >= MAX_FOLDER_ITEMS)
                throw new IOException("当前目录超过 3000 个项目，请通过子文件夹浏览");
        }
        return all;
    }

    public static List<Entry> collectFolder(Server server, String folderId) throws Exception {
        List<Entry> tracks = new ArrayList<>();
        collect(server, folderId, tracks, new HashSet<>(), 0);
        return tracks;
    }

    private static void collect(Server server, String id, List<Entry> tracks,
                                Set<String> visited, int depth) throws Exception {
        if (depth > 20) throw new IOException("目录层级过深，停止递归");
        if (!visited.add(id)) return;
        for (Entry entry : browse(server, id)) {
            if (entry.folder) collect(server, entry.id, tracks, visited, depth + 1);
            else if (entry.playable()) {
                if (tracks.size() >= MAX_PLAYLIST_TRACKS)
                    throw new IOException("文件夹歌曲超过 1000 首。请进入子文件夹分批播放。");
                tracks.add(entry);
            }
        }
    }

    private static byte[] postBrowse(Server server, String id, int start, int count) throws Exception {
        String soap = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
                "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                "<s:Body><u:Browse xmlns:u=\"" + xml(server.serviceType) + "\">" +
                "<ObjectID>" + xml(id) + "</ObjectID>" +
                "<BrowseFlag>BrowseDirectChildren</BrowseFlag><Filter>*</Filter>" +
                "<StartingIndex>" + start + "</StartingIndex>" +
                "<RequestedCount>" + count + "</RequestedCount><SortCriteria></SortCriteria>" +
                "</u:Browse></s:Body></s:Envelope>";
        HttpURLConnection conn = (HttpURLConnection) new URL(server.controlUrl).openConnection();
        conn.setConnectTimeout(5000); conn.setReadTimeout(15000);
        conn.setRequestMethod("POST"); conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
        conn.setRequestProperty("SOAPACTION", "\"" + server.serviceType + "#Browse\"");
        try {
            byte[] data = soap.getBytes(StandardCharsets.UTF_8);
            try (OutputStream stream = conn.getOutputStream()) { stream.write(data); }
            int status = conn.getResponseCode();
            if (status / 100 != 2) throw new IOException("DLNA 浏览失败，HTTP " + status);
            try (InputStream input = conn.getInputStream()) { return readLimited(input); }
        } finally { conn.disconnect(); }
    }

    private static int countChildren(Element didl) {
        int count = 0;
        NodeList nodes = didl.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            if (nodes.item(i) instanceof Element) count++;
        }
        return count;
    }

    private static List<Entry> parseEntries(Document doc, String baseUrl) {
        List<Entry> items = new ArrayList<>();
        Element root = doc.getDocumentElement();
        NodeList nodes = root.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            if (!(node instanceof Element)) continue;
            Element el = (Element) node;
            String tag = local(el);
            boolean folder = "container".equals(tag);
            if (!folder && !"item".equals(tag)) continue;
            String id = el.getAttribute("id");
            if (id.isEmpty()) continue;
            String title = firstText(el, "title");
            if (title.isEmpty()) title = "未命名";
            String cls = firstText(el, "class").toLowerCase(Locale.ROOT);
            String artist = firstText(el, "artist");
            String album = firstText(el, "album");
            String cover = resolve(baseUrl, firstText(el, "albumArtURI"));
            String mediaUrl = "";
            boolean isAudio = cls.contains("audioitem") || cls.contains("musictrack");
            if (!folder) {
                NodeList descendants = el.getElementsByTagName("res");
                if (descendants.getLength() == 0) descendants = el.getElementsByTagNameNS("*", "res");
                for (int j = 0; j < descendants.getLength(); j++) {
                    Element res = (Element) descendants.item(j);
                    String url = res.getTextContent() == null ? "" : res.getTextContent().trim();
                    String protocol = res.getAttribute("protocolInfo").toLowerCase(Locale.ROOT);
                    boolean audio = protocol.contains(":audio/") || protocol.contains(":application/ogg")
                            || looksAudio(url) || looksAudio(title);
                    String resolved = resolve(baseUrl, url);
                    if ((audio || isAudio) && (resolved.startsWith("http://") || resolved.startsWith("https://"))) {
                        mediaUrl = resolved;
                        if (audio) break;
                    }
                }
                if (!isAudio && !looksAudio(title) && mediaUrl.isEmpty()) continue;
            }
            items.add(new Entry(id, title, artist, album, mediaUrl, cover, folder));
        }
        return items;
    }

    private static boolean looksAudio(String value) {
        String v = value.toLowerCase(Locale.ROOT).split("\\?", 2)[0];
        return v.matches(".*\\.(mp3|flac|wav|m4a|aac|ogg|opus|wma|aif|aiff|ape|alac|dsf|dff)$");
    }
    private static int intOr(String value, int fallback) {
        try { return Integer.parseInt(value.trim()); }
        catch (Exception ex) { return fallback; }
    }
    private static String resolve(String base, String raw) {
        if (raw == null || raw.trim().isEmpty()) return "";
        try { return new URL(new URL(base), raw.trim()).toString(); }
        catch (Exception ex) { return ""; }
    }
    private static String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }
    private static byte[] fetch(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(5000); conn.setReadTimeout(10000);
        try {
            if (conn.getResponseCode() / 100 != 2) throw new IOException("无法获取 DLNA 设备描述：HTTP " + conn.getResponseCode());
            try (InputStream input = conn.getInputStream()) { return readLimited(input); }
        } finally { conn.disconnect(); }
    }
    private static byte[] readLimited(InputStream input) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192]; int n;
        while ((n = input.read(buffer)) != -1) {
            if (out.size() + n > 8 * 1024 * 1024) throw new IOException("DLNA 返回的数据太大");
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }
    private static Document parse(byte[] bytes) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        // The built-in Android DOM factory differs by OS version. Reject DTDs
        // before parsing and apply supported protections without breaking older TVs.
        if (new String(bytes, StandardCharsets.ISO_8859_1)
                .toUpperCase(Locale.ROOT).contains("<!DOCTYPE"))
            throw new IOException("DLNA XML 含有禁止的 DTD 声明");
        try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); }
        catch (Exception ignored) { /* Explicit DTD rejection above. */ }
        try { f.setFeature("http://xml.org/sax/features/external-general-entities", false); }
        catch (Exception ignored) { }
        try { f.setFeature("http://xml.org/sax/features/external-parameter-entities", false); }
        catch (Exception ignored) { }
        try { f.setXIncludeAware(false); }
        catch (UnsupportedOperationException ignored) { }
        f.setExpandEntityReferences(false);
        return f.newDocumentBuilder().parse(new InputSource(new ByteArrayInputStream(bytes)));
    }
    private static String local(Node n) {
        String name = n.getLocalName();
        if (name == null) name = n.getNodeName();
        int colon = name.indexOf(':');
        return colon >= 0 ? name.substring(colon + 1) : name;
    }
    private static Element firstElement(Element element, String localName) {
        if (element == null) return null;
        if (local(element).equals(localName)) return element;
        NodeList all = element.getElementsByTagNameNS("*", localName);
        if (all.getLength() > 0) return (Element) all.item(0);
        all = element.getElementsByTagName(localName);
        return all.getLength() > 0 ? (Element) all.item(0) : null;
    }
    private static String firstText(Element element, String localName) {
        Element found = firstElement(element, localName);
        return found == null ? "" : found.getTextContent().trim();
    }
}
