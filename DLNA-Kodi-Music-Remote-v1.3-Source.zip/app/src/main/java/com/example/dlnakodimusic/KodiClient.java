package com.example.dlnakodimusic;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

/** Kodi remote via HTTP JSON-RPC. Audio playlist ID is 0. */
public final class KodiClient {
    private String host = "", user = "", password = "";
    private int port = 8080;

    public void configure(String host, int port, String user, String password) {
        this.host = host.trim(); this.port = port;
        this.user = user; this.password = password;
    }
    public void ping() throws Exception {
        String pong = rpc("JSONRPC.Ping", new JSONObject()).optString("result", "");
        if (!"pong".equalsIgnoreCase(pong)) throw new IOException("Kodi 未正确响应");
    }
    public void play(List<DlnaClient.Entry> tracks) throws Exception {
        if (tracks.isEmpty()) throw new IOException("没有可播放的音乐文件");
        rpc("Playlist.Clear", new JSONObject().put("playlistid", 0));
        for (int start = 0; start < tracks.size(); start += 100) {
            JSONArray items = new JSONArray();
            for (int i = start; i < Math.min(tracks.size(), start + 100); i++)
                items.put(new JSONObject().put("file", tracks.get(i).mediaUrl));
            rpc("Playlist.Add", new JSONObject().put("playlistid", 0).put("item", items));
        }
        rpc("Player.Open", new JSONObject().put("item", new JSONObject().put("playlistid", 0)));
    }
    public void toggle() throws Exception {
        rpc("Player.PlayPause", new JSONObject().put("playerid", 0));
    }
    public void next() throws Exception {
        rpc("Player.GoTo", new JSONObject().put("playerid", 0).put("to", "next"));
    }
    public void previous() throws Exception {
        rpc("Player.GoTo", new JSONObject().put("playerid", 0).put("to", "previous"));
    }
    public void stop() throws Exception {
        rpc("Player.Stop", new JSONObject().put("playerid", 0));
    }
    public void seek(int percentage) throws Exception {
        rpc("Player.Seek", new JSONObject().put("playerid", 0)
                .put("value", new JSONObject().put("percentage", Math.max(0, Math.min(100, percentage)))));
    }
    public void volume(int value) throws Exception {
        rpc("Application.SetVolume", new JSONObject().put("volume", Math.max(0, Math.min(100, value))));
    }

    public static final class State {
        public boolean playing, paused, canSeek;
        public int volume, playlistPosition = -1;
        public double percentage;
        public String title = "未播放", artist = "", album = "", thumbnail = "", file = "";
        public String time = "00:00 / 00:00";
    }

    public State state() throws Exception {
        State state = new State();
        JSONObject volume = rpc("Application.GetProperties",
                new JSONObject().put("properties", new JSONArray().put("volume")));
        state.volume = volume.getJSONObject("result").optInt("volume", 50);
        JSONArray players = rpc("Player.GetActivePlayers", new JSONObject()).getJSONArray("result");
        boolean audioFound = false;
        for (int i = 0; i < players.length(); i++) {
            JSONObject player = players.getJSONObject(i);
            if (player.optInt("playerid", -1) == 0 && "audio".equals(player.optString("type"))) {
                audioFound = true; break;
            }
        }
        if (!audioFound) return state;
        state.playing = true;
        JSONObject props = rpc("Player.GetProperties", new JSONObject().put("playerid", 0)
                .put("properties", new JSONArray().put("speed").put("time")
                        .put("totaltime").put("percentage").put("position").put("canseek")))
                .getJSONObject("result");
        state.paused = props.optInt("speed", 0) == 0;
        state.canSeek = props.optBoolean("canseek", false);
        state.percentage = props.optDouble("percentage", 0);
        state.playlistPosition = props.optInt("position", -1);
        state.time = formatTime(props.optJSONObject("time")) + " / " + formatTime(props.optJSONObject("totaltime"));
        JSONObject item = rpc("Player.GetItem", new JSONObject().put("playerid", 0)
                .put("properties", new JSONArray().put("title").put("artist")
                        .put("album").put("thumbnail").put("file"))).getJSONObject("result").optJSONObject("item");
        if (item != null) {
            state.title = item.optString("title", "");
            if (state.title.isEmpty()) state.title = item.optString("label", "播放中");
            state.album = item.optString("album", "");
            state.file = item.optString("file", "");
            JSONArray artists = item.optJSONArray("artist");
            if (artists != null && artists.length() > 0) state.artist = artists.optString(0);
            state.thumbnail = item.optString("thumbnail", "");
        }
        return state;
    }
    private static String formatTime(JSONObject time) {
        if (time == null) return "00:00";
        int hours = time.optInt("hours");
        int minutes = time.optInt("minutes");
        int seconds = time.optInt("seconds");
        if (hours > 0) return String.format(java.util.Locale.US, "%d:%02d:%02d", hours, minutes, seconds);
        return String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds);
    }

    private JSONObject rpc(String method, JSONObject params) throws Exception {
        if (host.isEmpty()) throw new IOException("请先填写 Kodi 的 IP 地址并保存连接");
        if (port < 1 || port > 65535) throw new IOException("Kodi 端口号无效");
        String hostname = host.contains(":") && !host.startsWith("[") ? "[" + host + "]" : host;
        HttpURLConnection conn = (HttpURLConnection) new URL("http://" + hostname + ":" + port + "/jsonrpc").openConnection();
        conn.setRequestMethod("POST"); conn.setDoOutput(true);
        conn.setConnectTimeout(4500); conn.setReadTimeout(12000);
        conn.setRequestProperty("Content-Type", "application/json");
        if (!user.isEmpty() || !password.isEmpty()) {
            String credentials = user + ":" + password;
            String token = Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
            conn.setRequestProperty("Authorization", "Basic " + token);
        }
        try {
            JSONObject request = new JSONObject().put("jsonrpc", "2.0")
                    .put("id", 1).put("method", method).put("params", params);
            try (OutputStream stream = conn.getOutputStream()) {
                stream.write(request.toString().getBytes(StandardCharsets.UTF_8));
            }
            int status = conn.getResponseCode();
            if (status == 401) throw new IOException("Kodi 用户名或密码错误（HTTP 401）");
            if (status / 100 != 2) throw new IOException("Kodi HTTP " + status + "，检查 IP、端口和 HTTP 控制设置");
            String response;
            try (InputStream input = conn.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096]; int n;
                while ((n = input.read(buffer)) != -1) {
                    if (output.size() + n > 2 * 1024 * 1024) throw new IOException("Kodi 返回数据过大");
                    output.write(buffer, 0, n);
                }
                response = output.toString("UTF-8");
            }
            JSONObject object = new JSONObject(response);
            if (object.has("error")) {
                JSONObject err = object.optJSONObject("error");
                String message = err == null ? object.optString("error") : err.optString("message", "Kodi 命令失败");
                throw new IOException(method + ": " + message);
            }
            if (!object.has("result")) throw new JSONException("Kodi 响应缺少 result 字段");
            return object;
        } finally { conn.disconnect(); }
    }
}
