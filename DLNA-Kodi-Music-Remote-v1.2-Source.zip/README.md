# DLNA → Kodi Music Remote · Android 手机端

**目标**：手机通过 DLNA/UPnP 浏览局域网硬盘音乐，将歌曲 HTTP 地址发送到 Google TV 上现有的 Kodi。**真正读取和播放音乐文件的是电视 Kodi，手机并非音乐中转服务器。** 不需电视安装配套 APK，不改动现有 SMB 视频目录或 Kodi 视频资料库。

## 已实现功能

- SSDP 自动搜索局域网 UPnP MediaServer，选择设备；支持手工输入设备描述 XML URL 作为备用方式。
- 通过 DLNA `ContentDirectory:Browse` 浏览目录，分页获取音乐文件、歌手、专辑以及服务器提供的专辑封面。
- 点击单曲立即发送电视；点击文件夹进入浏览；文件夹右侧播放键可递归播放其中音乐（含子目录，单次最多 1000 首）。
- 单曲勾选、多选、全选/取消全选、播放已选，按目录显示顺序加入播放列表。
- 通过 Kodi HTTP JSON-RPC 清空/建立音频播放列表并开始播放；上一首、下一首、播放/暂停、停止、进度跳转、调整 Kodi 音量。
- 同步读取 Kodi 当前播放器状态、歌曲与时间；手机端记住最近发送的曲目名称、歌手和封面。无封面时不会伪造封面。
- Kodi IP、端口、用户名和密码保存在手机本地应用偏好设置里。

## 电视 Kodi 端必须设置（非常重要）

1. **Kodi → 设置 → 服务 → 控制**（Services → Control）。
2. 开启 **「允许通过 HTTP 远程控制」**（Allow remote control via HTTP），记下端口号（常见为 **8080**，以 Kodi 实际设置为准）。
3. 如果 Kodi 要求身份验证，在该页面设置并记下 **用户名 / 密码**。建议保持身份验证开启。请勿把这个 HTTP 服务转发到外网。
4. 让 **Kodi 保持运行**，手机与 Google TV、DLNA 硬盘需在同一个可以相互访问的局域网。
5. 此 App 使用 HTTP JSON-RPC 控制，不依赖「启用 UPnP 支持」或「允许 UPnP 远程控制」来遥控 Kodi；这两个设置并不能代替第 2 步。

## 手机 App 操作

1. 安装 `app-debug.apk`，打开后点「连接设置」。
2. 输入电视 Google TV 的局域网 IP、Kodi HTTP 端口、账号、密码，点击「保存并测试 Kodi 连接」。
3. 点击「扫描」，选择你的 DLNA 服务器（例如 `MediaShare:1`）。自动发现不成功时可以尝试「手动」输入服务器设备描述 XML URL。
4. 点击文件夹进入；点击单曲立即播；点击文件夹右侧 `▶` 会播放该文件夹全部音乐。
5. 勾选多首歌或点「全选 / 取消」，再点击「▶ 已选(n)」。
6. 底部控制栏有上一首、播放暂停、下一首、停止、进度和音量。

## GitHub Actions 编译 APK

**不能把 ZIP 原样上传到仓库后直接编译。先解压 ZIP，把解压后的文件夹内容上传到仓库根目录。** 根目录必须包含：

```
.github/workflows/build.yml
app/build.gradle
app/src/main/AndroidManifest.xml
app/src/main/java/com/example/dlnakodimusic/*.java
build.gradle
settings.gradle
gradle.properties
```

新建空 GitHub 仓库，然后把项目所有文件（包括隐藏目录 `.github`）放在仓库根目录、提交。在 GitHub 仓库点击 **Actions → Build Android APK → Run workflow**，或者向 `main`/`master` 推送源码自动编译。

编译成功后，打开本次 Actions 运行记录，页面下方 **Artifacts → DLNA-Kodi-Music-Remote-debug**，下载 ZIP，里面的 `app-debug.apk` 是可安装的 Android 调试 APK。

工程：Java 17 / Android Gradle Plugin 8.7.3 / Gradle 8.9 / compileSdk 35 / minSdk 26。仅使用 Android 系统 SDK，不含第三方依赖，不调用云服务。

## 局限和注意事项

- 不同 DLNA 服务器返回的歌曲 HTTP URL 及协议支持情况不同；服务器如果限制直接请求、需要特定认证/特殊 DLNA 请求头，可能导致 Kodi 无法播放。这一点必须用你的真实 DLNA 硬盘与 Kodi 实测。
- 并非将 DLNA 音乐扫描为 Kodi 本地歌手/专辑资料库；App 只是显示 DLNA 提供的元数据和封面，控制 Kodi 播放。
- 某些 DLNA 设备只能提供有限的 `albumArtURI`，没有封面时 App 会显示占位方块。
- 音乐播放列表固定使用 Kodi 音频播放列表 0，发起新播放时会替换该列表的现有歌曲；**不会修改 SMB 视频来源和视频资料库**。
- 当目录超过 1000 首时请分目录播放，避免一次性生成过大播放队列。
- 为访问本地 HTTP DLNA/Kodi 设备开启了明文 HTTP 权限，仅在可信任的局域网使用；不要把 Kodi HTTP 端口暴露到互联网。
- 设备的发现使用 SSDP 组播：访客 Wi-Fi、AP 隔离、跨子网或某些路由器会阻止发现，需调整 LAN 网络设置。
- 调试 APK 未经真实手机和电视联机测试；本项目对 DLNA XML、SOAP 目录解析和递归选择进行了本地模拟测试。若 Actions 或你的设备出现错误，以实际日志为准进行修复。
